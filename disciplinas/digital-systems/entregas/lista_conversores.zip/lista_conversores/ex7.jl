using Plots;

g(Vd, Vc, Vb, Va) = -1*(Va/8 + Vb/4 + Vc/2 + Vd/1);
Vo(x) = f(div(x, 8)%2, div(x, 4)%2, div(x,2)%2, x%2);

f(Vd, Vc, Vb, Va) = -1*(Va/8 + Vb/4 + Vc/1.5 + Vd/0.5);
Vk(x) = g(div(x, 8)%2, div(x, 4)%2, div(x,2)%2, x%2);

plot(0:15, [Vk, Vo],
	 label=["Valores corretos" "Valores com resistores errados"],
	 lc=[:black :red], line=(:steppost),
	 grid=:xy,
	 ylabel="Vo (V)", xlabel="Binary input VdVcVdVa, high level 1V, low level 0V",
	 xticks=0:15, yticks=0:-0.125:-3.5
);

savefig("graph_ex7.svg");
